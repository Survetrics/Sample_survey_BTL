import {
  AfterContentInit,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  forwardRef,
  Input,
  ViewChild
} from '@angular/core';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from "@angular/forms";
import {includes, isEqual} from 'lodash-es';

export const CHECKBOX_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => CheckboxComponent),
  multi: true
};
@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss'],
  providers: [CHECKBOX_VALUE_ACCESSOR]
})
export class CheckboxComponent implements AfterContentInit, ControlValueAccessor  {

  @Input() style: any
  @Input() disabled: any
  @Input() readonly : any
  @Input() binary: boolean = true
  @Input() formControl: any

  @Input() falseValue: any
  @Input() required: boolean = false;
  @Input() trueValue: any

  focused: boolean = false
  @Input() value: any

  @Input() styleClass: string = ''

  @Input() label: any

  onChange: EventEmitter<any>
  onModelChange: Function;
  onModelTouched: Function;

  @ViewChild('cb') inputViewChild: any
  model: any


  constructor(public cd: ChangeDetectorRef) {
    this.cd = cd;
    this.trueValue = true;
    this.falseValue = false;
    this.onChange = new EventEmitter();
    this.onModelChange = () => {
    };
    this.onModelTouched = () => {
    };
    this.focused = false;
  }

  ngAfterContentInit() {

  }

  onClick(event: any, checkbox: any, focus: any) {
    event.preventDefault();
    if (this.disabled || this.readonly) {
      return;
    }
    this.updateModel(event);
    if (focus) {
      checkbox.focus();
    }
  }

  updateModel(event: any) {
    console.log(this.value)
    let newModelValue;
    if (!this.binary) {
      console.log(this.checked())
      console.log(this.model)
      if (this.checked())
        newModelValue = this.model.filter((val: any) => !isEqual(val, this.value));
      else
        newModelValue = this.model ? [...this.model, this.value] : [this.value];
      console.log(this.model)
      this.onModelChange(newModelValue);
      this.model = newModelValue;
      if (this.formControl) {
        this.formControl.setValue(newModelValue);
      }
    } else {
      newModelValue = this.checked() ? this.falseValue : this.trueValue;
      this.model = newModelValue;
      this.onModelChange(newModelValue);
    }
    this.onChange.emit({checked: newModelValue, originalEvent: event});
  }

  handleChange(event: any) {
    if (!this.readonly) {
      this.updateModel(event);
    }
  }

  onFocus() {
    this.focused = true;
  }

  onBlur() {
    this.focused = false;
    this.onModelTouched();
  }

  focus() {
    this.inputViewChild.nativeElement.focus();
  }

  writeValue(model: any) {
    this.model = model;
    this.cd.markForCheck();
  }

  registerOnChange(fn: Function) {
    this.onModelChange = fn;
  }

  registerOnTouched(fn: Function) {
    this.onModelTouched = fn;
  }

  setDisabledState(val: any) {
    this.disabled = val;
    this.cd.markForCheck();
  }

  checked() {
    return this.binary ? this.model === this.trueValue : includes(this.value, this.model);
  }
}
