const LOCAL_STORAGE_AUTH_NAME = 'survetricsUser'

const Q11 = [
  {"name": "Bajaj Finance Limited", "code": 1},
  {"name": "Piramal Finance", "code": 2},
  {"name": "Shriram Finance", "code": 3},
  {"name": "Muthoot Finance Limited", "code": 4},
  {"name": "Manappuram Finance Limited", "code": 5},
  {"name": "Awas Housing Finance", "code": 6},
  {"name": "Edelweiss Financial Services Ltd.", "code": 7},
  {"name": "Motilal Oswal", "code": 8},
  {"name": "Aadhar Housing Finance", "code": 9},
  {"name": "L&T Finance Limited", "code": 10},
  {"name": "Tata Capital Financial Services Limited", "code": 11},
  {"name": "HDB Financial Services", "code": 12},
  {"name": "Cholamandalam Investment and Finance Company", "code": 13},
  {"name": "IIFL Finance Limited", "code": 14},
  {"name": "Poonawalla Housing Finance Limited", "code": 15},
  {"name": "Indiabulls Housing Finance Limited", "code": 16},
  {"name": "Reliance Home Finance Limited", "code": 17},
  {"name": "Godrej Housing Finance Limited", "code": 18},
  {"name": "Axis Bank Ltd.", "code": 19},
  {"name": "Bandhan Bank Ltd.", "code": 20},
  {"name": "Federal Bank Ltd.", "code": 21},
  {"name": "HDFC Bank Ltd", "code": 22},
  {"name": "ICICI Bank Ltd.", "code": 23},
  {"name": "IndusInd Bank Ltd", "code": 24},
  {"name": "IDFC FIRST Bank Limited", "code": 25},
  {"name": "Kotak Mahindra Bank Ltd", "code": 26},
  {"name": "Bank of Baroda", "code": 27},
  {"name": "Bank of India", "code": 28},
  {"name": "Bank of Maharashtra", "code": 29},
  {"name": "Canara Bank", "code": 30},
  {"name": "Central Bank of India", "code": 31},
  {"name": "Indian Overseas Bank", "code": 32},
  {"name": "Punjab National Bank", "code": 33},
  {"name": "State Bank of India", "code": 34},
  {"name": "Indian Bank", "code": 35},
  {"name": "Equitas Small Finance Bank", "code": 36},
  {"name": "Aditya Birla Finance Ltd", "code": 37},
]

const Q11Others = {"name": "Others", "code": 99}

export {
  LOCAL_STORAGE_AUTH_NAME,
  Q11,
  Q11Others,
}
