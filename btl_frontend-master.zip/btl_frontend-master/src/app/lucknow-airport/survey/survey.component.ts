import {Component} from '@angular/core';
import {AbstractControl, FormControl, FormGroup, Validators} from "@angular/forms";
import {NzModalService} from "ng-zorro-antd/modal";
import {SubmissionService} from "../../services/submission.service";
import {NO_WHITE_SPACES_ONLY} from "../../utils/common";
import {NzMessageService} from "ng-zorro-antd/message";
import {Q11, Q11Others} from "../../utils/constants";
import {AuthService} from "../../services/auth/auth.service";

const sleep = (time: number = 30000) => new Promise(resolve => setTimeout(resolve, time));

// 3, 5, 6d, 6e, 9a, 9b, 11, 12, 15
const RECORDINGS = [5, 7, 9, 9, 12, 13, 15, 16, 19]


@Component({
  selector: 'app-survey', templateUrl: './survey.component.html', styleUrls: ['./survey.component.scss']
})
export class SurveyComponent {
  // Stepper
  step: number = 0;
  MAX_STEP: number = 25;
  language: 'english' | 'hindi' = 'english'


  q1Hindi = ["पानीपत", "रोहतक", "अंबाला", "करनाल", "इंदौर", "ग्वालियर", "लुधियाना", "जालंधर", "अमृतसर", "मोहाली", "चंडीगढ़", "जोधपुर", "भीलवाड़ा", "उदयपुर", "अन्य"]
  q1English = ["Panipat", "Rohtak", "Ambala", "Karnal", "Indore", "Gwalior", "Ludhiana", "Jalandhar", "Amritsar", "Mohali", "Chandigarh", "Jodhpur", "Bhilwara", "Udaipur", "Others"]
  q1 = this.q1Hindi.map((each, index) => ({
    hindi: each, english: this.q1English[index]
  }))


  q1a = ["Haryana", "Madhya Pradesh", "Punjab", "Karnal", "Chandigarh", "Rajasthan",]

  q2Hindi = ['हां', 'नहीं']
  q2English = ['Yes', 'No']
  q2 = this.q2Hindi.map((each, index) => ({
    hindi: each, english: this.q2English[index]
  }))

  q2aHindi = ["मार्केट रिसर्च एजेंसी (जैसे नीलसन, कंतार, ईप्‍सोस आदि)", "विज्ञापन एजेंसी", "बैंक / एनबीएफसी / कोई भी फाइनेंशियल संस्था", "बीमा कंपनी/ ब्रोकरेज फर्म", "अन्य निजी संस्‍था/ बहुराष्ट्रीय कंपनियाँ", "सरकारी संस्‍था", "एफएमसीजी कंपनी", "दवा बनाने वाली कंपनी", "स्कूल/ कॉलेज में शिक्षक", "अन्य, (कृपया बतायें)"]
  q2aEnglish = ["Market Research Agency (Like Nielsen, KANTAR, IPSOS etc)", "Advertising Agency", "Bank/NBFC/Any Financial Institution", "Insurance Company/Brokerage Firm", "Other Private Organizations/MNCs", "Government Organizations", "FMCG Company", "Pharmaceutical Company", "Teacher in School/College", "Others (Please specify)"]
  q2a = this.q2aHindi.map((each, index) => ({
    hindi: each, english: this.q2aEnglish[index]
  }))


  q3a = ["Below 22 years", "22-30 years", "31-40 years", "41-50 years", "51-60 years", "More than 60"]

  q4Hindi = ['पुरुष', 'महिला',]
  q4English = ['Male', 'Female',]
  q4 = this.q4Hindi.map((each, index) => ({
    hindi: each, english: this.q4English[index]
  }))

  q5Hindi = ['मैं वह व्यक्ति हूं जो ज्‍यादातर फाइनेंशियल फैसलों के लिए जिम्मेदार हूं', 'मैं इस घर के फाइनेंशियल फैसलों के लिए अपने परिवार के सदस्यों के साथ मिलकर फैसला लेता हूं', 'नहीं, जब फाइनेंशियल सर्विसेस की खरीददारी की बात आती है तो मैं फैसला लेने की प्रक्रिया का हिस्सा नहीं हूं',]
  q5English = ['I am the person who is responsible for most of the financial decisions of this household', 'I take decisions jointly with my family members for the financial decisions of this household', 'No, I am not part of the decision-making process when it comes to purchasing financial services',]
  q5 = this.q5Hindi.map((each, index) => ({
    hindi: each, english: this.q5English[index]
  }))

  q6aHindi = ["सेलरीड/ वेतनभोगी", "बिना कर्मचारियों वाले  बिजनेसमैन/ इंडस्‍ट्रिलियस्‍ट", "1-9 कर्मचारियों वाले  बिजनेसमैन/ इंडस्‍ट्रिलियस्‍ट", "10 से ज्‍यादा कर्मचारियों वाले बिजनेसमैन/ इंडस्‍ट्रिलियस्‍ट", "सेल्‍फ-इंप्‍लॉयड (डॉक्टर, वकील, सीए आदि)", "काम नहीं कर रहा/ छात्र", "रिटायर्ड"]
  q6aEnglish = ["Salaried", "Businessman/Industrialist with No employees", "Businessman/Industrialist with 1-9 employees", "Businessman/Industrialist with 10+ employees", "Self-employed (Doctor, lawyer, CA etc.)", "Not working/Student", "Retired"]
  q6a = this.q6aHindi.map((each, index) => ({
    hindi: each, english: this.q6aEnglish[index]
  }))

  q6dHindi = ["10,000 से कम", "10,000-20,000", "20,000-30,000", "30,000-50,000", "50,000-75,000", "75000-1लाख", "1 लाख से ज्‍यादा"]
  q6dEnglish = ["Less than 10,000", "10,000-20,000", "20,000-30,000", "30,000-50,000", "50,000-75,000", "75,000-1 Lakh", "More than 1 Lakh"]
  q6d = this.q6dHindi.map((each, index) => ({
    hindi: each, english: this.q6dEnglish[index]
  }))

  q6eHindi = ["50,000 से कम", "50,000-100,000", "100,000-500,000", "500,000-15,00,000", "15,00,000-30,00,000", "30,00,000-50,00,000", "50,00,000-75,00,000", "75,00,000-1 करोड़", "1 करोड़ से ज्‍यादा",]
  q6eEnglish = ["Less than 50,000", "50,000-100,000", "100,000-500,000", "500,000-15,00,000", "15,00,000-30,00,000", "30,00,000-50,00,000", "50,00,000-75,00,000", "75,00,000-1 Cr", "More than 1Cr",]
  q6e = this.q6eHindi.map((each, index) => ({
    hindi: each, english: this.q6eEnglish[index]
  }))


  q7aHindi = ["अशिक्षित", "4 साल तक स्कूल/ कोई स्कूली शिक्षा नहीं लेकिन शिक्षित", "स्कूली शिक्षा 5-9 साल", "एक एसएससी/ एचएससी", "कॉलेज गये हैं लेकिन ग्रेजुएट नहीं (डिप्लोमा सहित)", "ग्रेजुएट सामान्य (जैसे बी.ए., बी.एससी., बी.कॉम)", "पोस्ट ग्रेजुएट जनरल (जैसे एम.ए., एम.एससी., एम.कॉम)", "ग्रेजुएट प्रोफेशनल (जैसे बी.ई., बी.टेक)", "पोस्ट ग्रेजुएट प्रोफेशनल (जैसे, एम.टेक, एमबीए, सीए, एमबीबीएस, एलएलबी)"]
  q7aEnglish = ["Illiterate", "School up to 4 years/no schooling but literate", "Schooling 5-9 years", "SSC/HSC", "Some college but not graduate (Incl. Diploma)", "Graduate General (e.g. B.A., B.Sc., B.Com)", "Post Graduate General (e.g. M.A., M.Sc., M.Com)", "Graduate Professional (e.g. B.E., B.Tech)", "Post Graduate professional (e.g., M.Tech, MBA, CA, MBBS, LLB)"]
  q7a = this.q7aHindi.map((each, index) => ({
    hindi: each, english: this.q7aEnglish[index]
  }))


  q7bHindi = ["अकुशल कामगार", "कुशल कामगार", "छोटा व्यापारी", "दुकानदार", "बिना कर्मचारियों वाले बिजनेसमैन/ इंडस्‍ट्रिलियस्‍ट", "1-9 कर्मचारियों वाले बिजनेसमैन/ इंडस्‍ट्रिलियस्‍ट", "10 से ज्‍यादा कर्मचारियों वाले बिजनेसमैन/ इंडस्‍ट्रिलियस्‍ट", "सेल्‍फ-इंप्‍लॉयड प्रोफेशनल", "क्‍लर्क/ सेल्‍समैन", "सुपरवाइजरी लेवल", "ऑफिसर/ एक्‍जीक्‍यूटिव- जूनियर", "ऑफिसर/ एक्‍जीक्‍यूटिव -मीडिल/ सीनियर", "हाउसवाइफ", "छात्र", "अन्‍य, (कृपया बतायें)"]
  q7bEnglish = [
    "Unskilled Worker",
    "Skilled Worker",
    "Petty Trader",
    "Shop Owner",
    "Businessman/Industrialist with No employees",
    "Businessman/Industrialist with 1-9 employees",
    "Businessman/Industrialist with 10+ employees",
    "Self-employed Professional",
    "Clerical/Salesman",
    "Supervisory Level",
    "Officer/Executive – Junior",
    "Officer/Executive -Middle/Senior",
    "Housewife",
    "Student",
    "Others (Please specify)"
  ]
  q7b = this.q7bHindi.map((each, index) => ({
    hindi: each, english: this.q7bEnglish[index]
  }))


  q8Map: any = {
    "1-1": "E2",
    "2-1": "E2",
    "3-1": "E2",
    "4-1": "D",
    "5-1": "D",
    "6-1": "C",
    "7-1": "B1",
    "8-1": "D",
    "9-1": "D",
    "10-1": "D",
    "11-1": "C",
    "12-1": "B1",


    "1-2": "E2",
    "2-2": "E1",
    "3-2": "D",
    "4-2": "D",
    "5-2": "C",
    "6-2": "B2",
    "7-2": "B1",
    "8-2": "D",
    "9-2": "D",
    "10-2": "D",
    "11-2": "C",
    "12-2": "B1",


    "1-3": "E1",
    "2-3": "D",
    "3-3": "D",
    "4-3": "C",
    "5-3": "B2",
    "6-3": "B2",
    "7-3": "A2",
    "8-3": "D",
    "9-3": "D",
    "10-3": "C",
    "11-3": "C",
    "12-3": "B1",

    "1-4": "D",
    "2-4": "C",
    "3-4": "C",
    "4-4": "B2",
    "5-4": "B1",
    "6-4": "B1",
    "7-4": "A2",
    "8-4": "B2",
    "9-4": "C",
    "10-4": "C",
    "11-4": "B2",
    "12-4": "B1",


    "1-5": "D",
    "2-5": "C",
    "3-5": "C",
    "4-5": "B1",
    "5-5": "A2",
    "6-5": "A2",
    "7-5": "A1",
    "8-5": "B1",
    "9-5": "B2",
    "10-5": "B2",
    "11-5": "B1",
    "12-5": "A2",


    "1-6": "D",
    "2-6": "B2",
    "3-6": "B1",
    "4-6": "A2",
    "5-6": "A2",
    "6-6": "A1",
    "7-6": "A1",
    "8-6": "A2",
    "9-6": "B1",
    "10-6": "B1",
    "11-6": "A2",
    "12-6": "A1",


    "1-7": "D",
    "2-7": "B2",
    "3-7": "B1",
    "4-7": "A2",
    "5-7": "A2",
    "6-7": "A1",
    "7-7": "A1",
    "8-7": "A2",
    "9-7": "B1",
    "10-7": "B1",
    "11-7": "A2",
    "12-7": "A1",


    "1-8": "D",
    "2-8": "B2",
    "3-8": "B2",
    "4-8": "A2",
    "5-8": "A1",
    "6-8": "A1",
    "7-8": "A1",
    "8-8": "A1",
    "9-8": "B1",
    "10-8": "A2",
    "11-8": "A2",
    "12-8": "A1",


    "1-9": "D",
    "2-9": "B2",
    "3-9": "B2",
    "4-9": "A2",
    "5-9": "A1",
    "6-9": "A1",
    "7-9": "A1",
    "8-9": "A1",
    "9-9": "B1",
    "10-9": "A2",
    "11-9": "A2",
    "12-9": "A1",
  }
  q8 = ["A1", "A2", "B1", "B2", "C", "D", "E1", "E2"]

  q10Hindi = ["बचत बैंक खाता", "राष्ट्रीयकृत/ प्राइवेट बैंक में फिक्‍स्‍ड डिपॉजिट", "म्यूचुअल फंड्स", "लाइफ इंश्‍योरेंस - सरकारी कंपनी", "लाइफ इंश्‍योरेंस - प्राइवेट कंपनी", "केवीपी/ एमआईएस जैसी पोस्‍ट ऑफिस की योजनाएं", "सार्वजनिक भविष्य निधि (पीपीएफ)", "स्टॉक/ शेयर", "राष्ट्रीय बचत प्रमाणपत्र (एनएससी)", "राष्ट्रीय पेंशन योजना (एनपीएस)", "राष्ट्रीयकृत/ प्राइवेट बैंक में रिकरिंग डिपॉजिट", "हेल्‍थ इंश्‍योरेंस", "भविष्य/ विकल्प", "कमोडिटी मार्केट", "करेंसी ट्रेडिंग", "सोना", "बांड्स", "जनरल इंश्‍योरेंस (जैसे मोटर, ट्रैवल आदि, हेल्‍थ इंश्‍योरेंस को छोड़कर)", "दुर्घटना बीमा", "रियल एस्टेट", "कोई नहीं/ पता नहीं/ कह नहीं सकते"]
  q10English = ["Savings Bank Account", "Fixed Deposit in Nationalized/Private Bank", "Mutual Funds", "Life Insurance - Government Company", "Life Insurance - Private Company", "Post Office Schemes like KVP/MIS", "Public Provident Fund (PPF)", "Stocks/Shares", "National Savings Certificate (NSC)", "National Pension Scheme (NPS)", "Recurring Deposit in Nationalized/Private Bank", "Health Insurance", "Future/Options", "Commodities Market", "Currency Trading", "Gold", "Bonds", "General Insurance (Motor, Travel, etc. excluding Health Insurance)", "Accident Insurance", "Real Estate", "None/DK/CS"]
  q10 = this.q10Hindi.map((each, index) => ({
    hindi: each, english: this.q10English[index]
  }))

  q11 = [...Q11]

  q13 = [...Q11]

  q15Hindi = ['पीरामल (या परिमल या नाम का कोई अन्य उच्चारण)', 'गलत विवरण',]
  q15English = ['Piramal (OR Parimal or some other pronunciation of the name)', 'Wrong attribution',]
  q15 = this.q15Hindi.map((each, index) => ({
    hindi: each, english: this.q15English[index]
  }))

  q16Hindi = ["लोन लेने के लिए कॉल करने के लिए नंबर", "उस व्यक्ति की इमेज जिसने लोन लिया है", "पीरामल लोगो", "पीरामल नाम", "नियति का ज़िक्र", "और कुछ, कृपया बतायें _____"]
  q16English = ["Number to call to get a Loan", "Image of the person who has taken a loan", "Piramal Logo", "Piramal name", "The mention of Neeyat", "Anything else, Please mention"]
  q16 = this.q16Hindi.map((each, index) => ({
    hindi: each, english: this.q16English[index]
  }))


  q17Hindi = ["उस नंबर पर कॉल किया जो बिलबोर्ड पर दिया गया था", "पास में ही पीरामल की ब्रांच पर गया था", "पीरामल वेबसाइट देखी थी", "गूगल पर पीरामल फाइनेंस सर्च किया था", "मैंने अपने दोस्तों को इस विज्ञापन के बारे में बताया था", "और कुछ, कृपया बतायें _____", "बाद में कॉल करने के लिए नंबर सेव कर लिया", "कुछ नहीं किया था"]
  q17English = ["Called the Number which was mentioned on the Billboard", "Visited the Branch of Piramal which was nearby", "Visited the Piramal website", "Searched for Piramal Finance on Google", "I told my friends about this Ad", "Anything else, Please mention", "Saved the number for use later", "Did not do anything"]
  q17 = this.q17Hindi.map((each, index) => ({
    hindi: each, english: this.q17English[index]
  }))


  q17aHindi = ["लोन के बारे में पूछताछ की थी", "उपलब्ध सर्विसेज के बारे में पूछताछ की थी", "लोन के लिए आवेदन किया -", "मैं बस यह देखना चाहता था कि क्या बैंक असली है और उसकी कोई शाखा है या नहीं", "यह जानना चाहता था कि क्या मैं लोन के लिए पात्र हूं", "मैंने अभी शाखा को बाहर से देखा था", "कुछ और कृपया बतायें _____"]
  q17aEnglish = ["Enquired about a loan", "Enquired about the services available", "Applied for a loan", "Just wanted to see if the bank was real and had a branch", "Wanted to check if I was eligible for a loan", "I just saw the branch from outside", "Something else, Please mention"]
  q17a = this.q17aHindi.map((each, index) => ({
    hindi: each, english: this.q17aEnglish[index]
  }))


  q18 = this.q2


  q19Hindi = ["इसने मेरे जैसे लोगों को दिखाया है", "इससे पता चलता है कि कंपनी मेरे जैसे लोगों को लोन देती है", "इससे पता चलता है कि कंपनी नियत के आधार पर लोन देती है", "इससे पता चलता है कि कंपनी कम दस्तावेजों के साथ लोन देती है", "इससे पता चलता है कि कंपनी होम लोन देती है", "इससे पता चलता है कि कंपनी मेरे जैसे लोगों के लिए सोचती है", "इससे पता चलता है कि कंपनी पर मेरे जैसे लोगों का भरोसा है", "मुझे बिलबोर्ड पसंद नहीं आया", "बिलबोर्ड जो दिखाता है वह सही नहीं है", "बिलबोर्ड मेरे लिए लागू नहीं है", "बिलबोर्ड मेरे जैसे लोगों के बारे में बात नहीं करता", "अन्य, कृपया बतायें- _____"]
  q19English = ["It has shown people like me", "It shows that the company gives loans to people like me", "It shows that the company gives loans on the basis of Neeyat", "It shows that the company gives loans with fewer documents", "It shows the company gives Home Loans", "It shows that the company thinks for people like me", "It shows that the company is trusted by people like me", "I did not like the Billboard", "What the Billboard shows is not true", "The Billboard is not applicable for me", "The Billboard does not talk about people like me", "Others, Please mention"]
  q19 = this.q19Hindi.map((each, index) => ({
    code: index + 1, hindi: each, english: this.q19English[index]
  }))

  q20Hindi = ["मैं उस कंपनी के पास आवेदन नहीं करूंगा जिसने बिलबोर्ड लगाया है", "मैं शायद उस कंपनी के लिए आवेदन नहीं करूंगा जिसने बिलबोर्ड लगाया है", "मैं उस कंपनी में आवेदन कर भी सकता हूं और नहीं भी, जिसने बिलबोर्ड लगाया है", "मैं शायद उस कंपनी के पास आवेदन करूंगा जिसने बिलबोर्ड लगाया है", "मैं उस कंपनी के पास आवेदन करूंगा जिसने बिलबोर्ड लगाया है"]
  q20English = ["I would not apply with the company which has put up the Billboard", "I would most probably not apply with the company which has put up the Billboard", "I may or may not apply with the company which has put up the Billboard", "I would most probably apply with the company which has put up the Billboard", "I would apply with the company which has put up the Billboard"]
  q20 = this.q20Hindi.map((each, index) => ({
    code: index + 1, hindi: each, english: this.q20English[index]
  }))

  surveySubmitStarted = false;

  surveyForm = new FormGroup<any>({
    name: new FormControl('', [Validators.required, NO_WHITE_SPACES_ONLY]),
    contactNumber: new FormControl('', [Validators.required]),
    address: new FormControl('', [Validators.required, NO_WHITE_SPACES_ONLY]),
    surveyorName: new FormControl('', [Validators.required, NO_WHITE_SPACES_ONLY]),
    surveyorId: new FormControl('', [Validators.required, NO_WHITE_SPACES_ONLY]),


    q1: new FormControl<number | null>(null, [Validators.required]),
    q1a: new FormControl<any>(null, [Validators.required]),

    q2: new FormControl<any>(null, [Validators.required]),
    q2a: new FormControl<any>(null, [Validators.required]),
    q2aExtra: new FormControl<any>('', [Validators.required, NO_WHITE_SPACES_ONLY]),

    q3: new FormControl<any>(null, [Validators.required]),
    q3a: new FormControl<any>(null, [Validators.required]),

    q4: new FormControl<any>(null, [Validators.required]),

    q5: new FormControl<any>(null, [Validators.required]),


    q6a: new FormControl<any>(null, [Validators.required]),
    q6d: new FormControl<any>(null, [Validators.required]),
    q6e: new FormControl<any>(null, [Validators.required]),


    q7a: new FormControl<any>(null, [Validators.required]),
    q7b: new FormControl<any>(null, [Validators.required]),
    q7bExtra: new FormControl<any>(null, [Validators.required, NO_WHITE_SPACES_ONLY]),

    // q8 is derived

    q9a: new FormControl<any>(null, [Validators.required]),
    q9b: new FormControl<any>(null, [Validators.required]),

    q10: new FormControl<any>([], [Validators.required]),


    q11: new FormControl<any>(null, [Validators.required]),
    q11Extra: new FormControl<any>(null, [Validators.required, NO_WHITE_SPACES_ONLY]),

    q12: new FormControl<any>([], [Validators.required]),
    q12Extra: new FormControl<any>(null, [Validators.required, NO_WHITE_SPACES_ONLY]),

    q12a: new FormControl<any>(null, [Validators.required]),

    q13: new FormControl<any>([], [Validators.required]),
    q13Extra: new FormControl<any>(null, [Validators.required, NO_WHITE_SPACES_ONLY]),

    q14: new FormControl<any>(null, [Validators.required]),

    q15: new FormControl<any>(null, [Validators.required]),

    q16: new FormControl<any>(null, [Validators.required]),
    q16Extra: new FormControl<any>(null, [Validators.required, NO_WHITE_SPACES_ONLY]),

    q17: new FormControl<any>(null, [Validators.required]),
    q17Extra: new FormControl<any>(null, [Validators.required, NO_WHITE_SPACES_ONLY]),

    q17a: new FormControl<any>(null, [Validators.required]),
    q17aExtra: new FormControl<any>(null, [Validators.required, NO_WHITE_SPACES_ONLY]),

    q18: new FormControl<any>(null, [Validators.required]),

    q19: new FormControl<any>(null, [Validators.required]),
    q19Extra: new FormControl<any>(null, [Validators.required, NO_WHITE_SPACES_ONLY]),

    q20: new FormControl<any>(null, [Validators.required]),

    interviewDateStart: new FormControl<any>(null),

  })

  stepMap: any = {

    2: {
      controls: ["q1"], question: [{
        hindi: "Q1. कृपया क्या आप हमें बता सकते हैं कि आप इस समय किस शहर में रह रहे हैं? ",
        english: "Q1. Can you kindly tell us which city you are currently residing in?"
      }]
    },

    3: {
      controls: ["q2"], question: [{
        hindi: "Q2. क्या आपने पिछले 6 महीनों में किसी मार्केट रिसर्च गतिविधि में सम्‍मिलित हुये हैं या भाग लिया है? ",
        english: "Q2. Have you attended or participated in any market research activity in the last 6 months?"
      }]
    },

    4: {
      controls: ["q2a"], question: [{
        hindi: "Q2a. कृपया अब हमें बताएं कि क्या आप इनमें से किसी संस्‍था में काम करते हैं? ",
        english: "Q2a. Now kindly tell us do you work in any of these organisations?"
      },

        {
          hindi: "कृपया बतायें", english: "Please specify"
        }

      ],

    },


    5: {
      controls: ["q3"], question: [{
        hindi: "Q3. कृपया अपनी उम्र बतायें", english: "Q3. Please mention your age"
      }]
    },


    6: {
      controls: ["q4"], question: [{
        hindi: "Q4. कृपया जेंडर चुनें", english: "Q4. Please select the gender"
      }]
    },


    7: {
      controls: ["q5"], question: [{
        hindi: "Q5. क्या आप अपने लिए या परिवार के अन्य सदस्यों के लिए फाइनेंशियल प्रोडक्‍ट्स की खरीददारी के संबंध में फैसला लेने वाले व्‍यक्ति हैं? इससे मेरा मतलब यह है कि बीमा, म्यूचुअल फंड, फिक्स्ड डिपॉजिट, होम लोन, क्रेडिट कार्ड और बैंकिंग प्रोडक्‍ट्स आदि जैसे फाइनेंशियल प्रोडक्‍ट खरीदते समय आप या तो मिलकर या अकेले फैसला लेते हैं।",
        english: "Q5. Are you the decision maker/s with regards to purchase of financial products for yourself or for other family members? By this, I mean, that you are either a joint or sole decision maker whenever buying financial products like Insurance, Mutual funds, Fixed Deposits, Home Loan, Credit Cards & Banking products etc."
      }]
    },


    8: {
      controls: ["q6a"], question: [{
        hindi: "Q6a. कृपया मुझे अपना इस समय का व्यवसाय बताएं।", english: "Q6a. Please tell me your Current Occupation."
      }]
    },


    9: {
      controls: ["q6d", "q6e"], question: [{
        hindi: "Q6d. कृपया हमें बताएं कि आपका मासिक वेतन क्‍या है?",
        english: "Q6d. Please tell us what your monthly salary is"
      }, {

        hindi: "Q6e. कृपया हमें बताएं कि आपके व्यवसाय/ स्वामित्व का महीने का टर्नओवर/ कारोबार क्या है?",
        english: "Q6e. Please tell us what is the monthly turnover of your business/proprietorship?"
      }]
    },

    10: {
      controls: ["q7a"], question: [{
        hindi: "Q7a. कृपया मुझे बताएं कि आपने पढ़ाई कहॉं तक की है?",
        english: "Q7a. Please tell me what is your current education level?"
      }]
    },


    11: {
      controls: ["q7b", "q7bExtra"], question: [{
        hindi: "Q7b. कृपया मुझे बताएं कि इस समय आपका व्यवसाय क्या है? कृपया इस सवाल का जवाब देते समय केवल अपनी मुख्‍य नौकरी या व्यवसाय के बारे में सोचें?",
        english: "Q7b. Please tell me what is your current occupation? Please think about only your primary job or occupation while answering this question?"
      },

        {
          hindi: "कृपया बतायें", english: "Please specify"
        }

      ]


    },


    12: {
      controls: ["q9a"], question: [{
        hindi: "Q9a. क्या आपके पास इस समय कोई लोन चल रहा है जिसे आपने अभी तक पूरी तरह से चुकाया नहीं है?",
        english: "Q9a. Do you currently have any ongoing loans which you have not yet fully repaid?"
      }]
    },

    13: {
      controls: ["q9b"], question: [{
        hindi: "Q9b. क्क्या आपका अगले 6 महीनों में लोन लेने का इरादा है?",
        english: "Q9b. Do you intend to take a loan in the next 6 months?"
      }]
    },


    14: {
      controls: ["q10"], question: [{
        hindi: "Q10. आपने इस समय नीचे दिये गये किन फाइनेंशियल प्रोडक्‍ट्स में निवेश किया है? इस समय निवेश से मेरा मतलब उन सभी निवेशों से है जो अभी भी सक्रिय/ चालू हैं, और जो बंद/ परिपक्व नहीं हुए हैं।",
        english: "Q10. In which all below mentioned financial products have you currently invested. By current investment, we mean all the investments that are still active/ ongoing, and which have not been closed/ matured."
      }]
    },

    15: {
      controls: ["q11", "q11Extra"], question: [{
        hindi: "Q11. जब आप लोन देने वाली फाइनेंश कंपनियों के बारे में सोचते हैं, तो आपके दिमाग में सबसे पहले कौन सी कंपनी का नाम आता है?",
        english: "Q11. When you think about Finance Companies providing Loans, which is the first company that comes to your mind?"
      },
        {
          hindi: "कृपया बतायें", english: "Please specify"
        }
      ]
    },


    16: {
      controls: ["q12", "q12Extra"], question: [{
        hindi: "Q12. और लोन देने वाली अन्य किन कंपनियों के बारे में आप जानते हैं?",
        english: "Q12. And which other companies that provide Loans are you aware of ?"
      }, {
        hindi: "कृपया बतायें", english: "Please specify"
      }]
    },


    17: {
      controls: ["q13", "q12Extra"], question: [{
        hindi: "Q13. आप इनमें से किस लोन देने वाली कंपनी के बारे में जानते हैं? कृपया इस लिस्‍ट को देखें और बताएं कि आपने इनमें से किसे कभी देखा या सुना है। लागू होने वाले सभी को चुनें।",
        english: "Q13. Which of these Loan giving companies are you aware of? Please look at this list and indicate which of these you have ever seen or heard of. Please select all that apply."
      },

        {
          hindi: "कृपया बतायें", english: "Please specify"
        }

      ]

    },


    18: {
      controls: ["q14"], question: [{
        hindi: "Q14. क्या आपने यह बिलबोर्ड अपने शहर में कहीं देखा है?",
        english: "Q14. Have you seen this billboard anywhere in your city?"
      }]
    },


    19: {
      controls: ["q15"], question: [{
        hindi: "Q15. क्क्या आप हमें बता सकते हैं कि यह बिलबोर्ड किस ब्रांड के लिए है?",
        english: "Q15. Could you tell us which brand this Billboard is for?"
      }]

    },


    20: {
      controls: ["q16", "q16Extra"], question: [{
        hindi: "Q16. आपने बताया कि आपने पीरामल द्वारा लगाया गया बिलबोर्ड देखा है, क्या आप हमें बता सकते हैं कि आपको बिलबोर्ड से क्या याद है?",
        english: "Q16. You said you have seen the Billboard put out by Piramal, could you tell us what you remember from the BillBoard? "
      },

        {
          hindi: "कृपया बतायें", english: "Please specify"
        }

      ]

    },


    21: {
      controls: ["q17", "q17Extra"], question: [{
        hindi: "Q17. आपने बताया कि आपने पीरामल द्वारा लगाया गया बिलबोर्ड देखा है, क्या आप हमें बता सकते हैं कि बिलबोर्ड देखने के बाद आपने क्या गतिविधि की थी?",
        english: "Q17. You said you have seen the Billboard put out by Piramal, could you tell us what action did you perform after seeing the BillBoard?"
      },
        {
          hindi: "कृपया बतायें", english: "Please specify"
        }
      ]

    },


    22: {
      controls: ["q17a", "q17aExtra"], question: [{
        hindi: "Q17a. आपने बताया कि आपने पीरामल ब्रांच पर गया था क्या आप हमें बता सकते हैं कि ब्रांच में जाने के बाद आपने क्या किया था?",
        english: "Q17a. You said you visited the Piramal branch. Could you tell us what did you do after visiting the branch? "
      },
        {
          hindi: "कृपया बतायें", english: "Please specify"
        }
      ]

    },


    23: {
      controls: ["q18"], question: [{
        hindi: "Q18. क्या आपने यह बिलबोर्ड अपने शहर में कहीं देखा है?",
        english: "Q18. Have you seen this billboard anywhere in your city? "
      }]

    },


    24: {
      controls: ["q19", "q19Extra"], question: [{
        hindi: "Q19. आपने इस बिलबोर्ड के बारे में क्या सोचा था?", english: "Q19. What did you think of this Billboard?"
      },
        {
          hindi: "कृपया बतायें", english: "Please specify"
        }
        ]

    },


    25: {
      controls: ["q20"], question: [{
        hindi: "Q20. यदि आपको अगले 3 महीनों में लोन लेना है और आपने यह बिलबोर्ड देखा है, तो आपके उस कंपनी के साथ आवेदन करने की कितनी संभावना है जिसने यह बिलबोर्ड लगाया है?",
        english: "Q20. If you were to take a loan in the next 3 months and saw this Billboard, how likely are you to apply with the company which has put up this Billboard?"
      }]

    },
  }

  recorder: any

  constructor(private modal: NzModalService, public submissionService: SubmissionService, public toastService: NzMessageService, public auth: AuthService,) {


    this.q11.sort((a, b) => a.name > b.name ? 1 : -1).push(Q11Others)

    this.q13.sort(() => Math.random() > 0.5 ? 1 : -1).push(Q11Others)

    this.q19.sort(() => Math.random() > 0.5 ? 1 : -1)
    this.q20.sort(() => Math.random() > 0.5 ? 1 : -1)

    RECORDINGS.forEach(each => {
      const formControl = new FormControl<any>(null)
      const controlName = `recording${each}`
      this.surveyForm.addControl(controlName, formControl, {})
    })

    this.surveyForm.patchValue({
      interviewDateStart: new Date(),
    })
    this.applyValidations()

    navigator.geolocation.getCurrentPosition(() => {

    }, (err) => {
      if (err.code === 1) {
        this.toastService.error('Please allow location permissions on this browser')
      }
    })
  }


  /**
   * Go to next step
   */
  async nextStep() {
    const formValue = this.surveyForm.getRawValue()
    // console.log(formValue)
    // Exit conditions
    if (formValue.q1 === 15) {
      this.openSurveyEndModal()
    } else if (formValue.q2 === 1) {
      this.openSurveyEndModal()
    } else if ([1, 2, 3].includes(formValue.q2a!)) {
      this.openSurveyEndModal()
    } else if ([1, 6].includes(formValue.q3a!)) {
      this.openSurveyEndModal()
    } else if (formValue.q5 === 3) {
      this.openSurveyEndModal()
    } else if ([6, 7].includes(formValue.q6a!)) {
      this.openSurveyEndModal()
    } else if ([1, 2].includes(formValue.q6d!)) {
      this.openSurveyEndModal()
    } else if (formValue.q7a! === 1) {
      this.openSurveyEndModal()
    } else if([13, 14].includes(formValue.q7b!)) {
      this.openSurveyEndModal()
    } else if ([2].includes(formValue.q9b!) && [2].includes(formValue.q9a!)) {
      this.openSurveyEndModal()
    } else if (this.step === 14 && (formValue.q10?.includes(21) || !formValue.q10?.includes(1))) {
      this.openSurveyEndModal()
    } else {
      if (this.step + 1 > this.MAX_STEP) {
        // Submit
        await this.submitSurveyForm();
      } else {
        this.goToNextStep(formValue)

        if(RECORDINGS.includes(this.step)) {
          const step = this.step
          this.recorder = await this.recordAudio()
          this.recorder.start()

          await sleep(20000)
          const audio = await this.recorder.stop()

          // PROCESS AUDIO THEN PATCH IN FORM

          this.surveyForm.patchValue({
            [`recording${step}`]: audio
          })

          // audio.play()
        }
      }
    }
  }

  async goToNextStep(formValue: any) {
    let nextStep = this.step + 1
    if (this.step === 18) {
      if (formValue.q14 === 1) {
        nextStep = 19
      } else {
        nextStep = 23
      }
    } else if (this.step === 19) {
      if (formValue.q15 === 1) {
        nextStep = 20
      } else {
        nextStep = 23
      }
    } else if (this.step === 21) {
      if (formValue.q17.includes(2)) {
        nextStep = 22
      } else {
        nextStep = 24
      }
    } else if (this.step === 22) {
      nextStep = 24
    } else if (this.step === 23) {
      if (formValue.q18 === 2) {
        await this.submitSurveyForm();
        return;
      } else {
        nextStep = 24
      }
    }

    if(nextStep === 17) {
      // get other 2 steps =>
      let alreadyInQuestions: number[] = []
      if(formValue.q11 && formValue.q11 !== 99) {
        alreadyInQuestions.push(formValue.q11!)
      }
      if(formValue.q12) {
        alreadyInQuestions.push(formValue.q12.filter((each: number) => each !== 99))
      }
      this.q13 = this.q13.filter(each => !alreadyInQuestions.includes(each.code))
    }

    this.step = nextStep > this.MAX_STEP ? this.MAX_STEP : nextStep;
  }

  /**
   * Go to previous step
   */
  prevStep() {
    let prevStep = this.step > 1 ? this.step - 1 : 1
    const formValue = this.surveyForm.getRawValue()
    if (this.step === 23) {
      if (formValue.q14 === 2) {
        prevStep = 18
      }

      if (formValue.q15 === 2) {
        prevStep = 19
      }
    }

    if (this.step === 24) {
      if (formValue.q18 === 1) {
        prevStep = 23
      }

      if (!formValue.q17.includes(2) && formValue.q17 !== null) {
        prevStep = 21
      }

      if (formValue.q17.includes(2)) {
        prevStep = 22
      }

    }

    if(this.step == 25) {
      if (!formValue.q17.includes(2) && formValue.q17 !== null) {
        prevStep = 21
      }

      if (formValue.q17.includes(2)) {
        prevStep = 22
      }
    }

    this.clearControl();
    this.step = prevStep
  }

  /**
   * Reset form and go to step 1
   */
  async goToStep1() {
    this.step = 1
    await this.recorder.stop()
    this.surveyForm.reset()
    this.surveyForm.patchValue({
      interviewDateStart: new Date(),
    })
  }

  get personalInformationFormControls() {
    return this.surveyForm.controls
  }

  get disableNext() {
    switch (this.step) {
      case 1:
        return this.personalInformationFormControls['name'].invalid || this.personalInformationFormControls['contactNumber'].invalid
            || this.personalInformationFormControls['surveyorName'].invalid || this.personalInformationFormControls['surveyorId'].invalid
      case 2:
        return this.personalInformationFormControls['q1'].invalid
      case 3:
        return this.personalInformationFormControls['q2'].invalid
      case 4:
        return this.personalInformationFormControls['q2a'].invalid || this.personalInformationFormControls['q2aExtra'].invalid
      case 5:
        return this.personalInformationFormControls['q3'].invalid
      case 6:
        return this.personalInformationFormControls['q4'].invalid
      case 7:
        return this.personalInformationFormControls['q5'].invalid
      case 8:
        return this.personalInformationFormControls['q6a'].invalid
      case 9:
        return this.personalInformationFormControls['q6e'].invalid || this.personalInformationFormControls['q6d'].invalid
      case 10:
        return this.personalInformationFormControls['q7a'].invalid;
      case 11:
        return this.personalInformationFormControls['q7b'].invalid || this.personalInformationFormControls['q7bExtra'].invalid
      case 12:
        return this.personalInformationFormControls['q9a'].invalid
      case 13:
        return this.personalInformationFormControls['q9b'].invalid
      case 14:
        return this.personalInformationFormControls['q10'].invalid;
      case 15:
        return this.personalInformationFormControls['q11'].invalid || this.personalInformationFormControls['q11Extra'].invalid;
      case 16:
        return this.personalInformationFormControls['q12'].invalid || this.personalInformationFormControls['q12Extra'].invalid;
      case 17:
        return this.personalInformationFormControls['q13'].invalid || this.personalInformationFormControls['q13Extra'].invalid;
      case 18:
        return this.personalInformationFormControls['q14'].invalid
      case 19:
        return this.personalInformationFormControls['q15'].invalid
      case 20:
        return this.personalInformationFormControls['q16'].invalid
      case 21:
        return this.personalInformationFormControls['q17'].invalid || this.personalInformationFormControls['q17Extra'].invalid
      case 22:
        return this.personalInformationFormControls['q17a'].invalid || this.personalInformationFormControls['q17aExtra'].invalid
      case 23:
        return this.personalInformationFormControls['q18'].invalid
      case 24:
        return this.personalInformationFormControls['q19'].invalid || this.personalInformationFormControls['q19Extra'].invalid
      case 25:
        return this.personalInformationFormControls['q20'].invalid
      default:
        return false;
    }
  }

  /**
   * Apply Validations
   */
  applyValidations() {

    // Q1
    this.personalInformationFormControls['q1'].valueChanges.subscribe({
      next: (value) => {
        let q1a = null;
        if (value! <= 4) {
          q1a = 1
        } else if (value! <= 6) {
          q1a = 2
        } else if (value! <= 10) {
          q1a = 3
        } else if (value! == 1) {
          q1a = 4
        } else if (value! <= 14) {
          q1a = 5
        }
        this.surveyForm.patchValue({
          q1a
        })
      }
    });

    // Q2A
    this.personalInformationFormControls['q2a'].valueChanges.subscribe({
      next: (value) => {
        if (value! === 10) {
          this.personalInformationFormControls['q2aExtra'].enable()
        } else {
          this.personalInformationFormControls['q2aExtra'].disable()
        }
        this.personalInformationFormControls['q2aExtra'].setValue('')
      }
    });

    // Q3
    this.personalInformationFormControls['q3'].valueChanges.subscribe({
      next: (value) => {
        let q3a: number
        if (value! < 22) {
          q3a = 1
        } else if (value! <= 30) {
          q3a = 2
        } else if (value! <= 40) {
          q3a = 3
        } else if (value! <= 50) {
          q3a = 4
        } else if (value! <= 60) {
          q3a = 5
        } else {
          q3a = 6
        }
        this.surveyForm.patchValue({
          q3a
        })
      }
    });

    // Q6A
    this.personalInformationFormControls['q6a'].valueChanges.subscribe({
      next: (value) => {
        if (value! === 1) {
          this.personalInformationFormControls['q6d'].enable()
          this.personalInformationFormControls['q6e'].disable()
        } else {
          this.personalInformationFormControls['q6d'].disable()
          this.personalInformationFormControls['q6e'].enable()
        }
      }
    });

    // Q7B
    this.personalInformationFormControls['q7b'].valueChanges.subscribe({
      next: (value) => {
        if (value! === 15) {
          this.personalInformationFormControls['q7bExtra'].enable()
        } else {
          this.personalInformationFormControls['q7bExtra'].disable()
        }
        this.personalInformationFormControls['q7bExtra'].setValue('')
      }
    });

    // Q10
    this.personalInformationFormControls['q10'].valueChanges.subscribe({
      next: (value) => {
        if (value && value.includes(21)) {
          this.personalInformationFormControls['q10'].setValue([21], {emitEvent: false});
        } else {
          this.personalInformationFormControls['q10'].setValue(value?.filter((each: number) => each !== 21), {emitEvent: false});
        }
      }
    });


    // Q11
    this.personalInformationFormControls['q11'].valueChanges.subscribe({
      next: (value: number | null) => {
        if (value && value == 99) {
          this.personalInformationFormControls['q11Extra'].enable();
        } else {
          this.personalInformationFormControls['q11Extra'].disable();
        }
        this.personalInformationFormControls['q11Extra'].setValue('');


      }
    })

    // Q12
    this.personalInformationFormControls['q12'].valueChanges.subscribe({
      next: (value: number[] | null) => {
        if (value && value.includes(99)) {
          // this.personalInformationFormControls['q10'].setValue([21], {emitEvent: false});
          this.personalInformationFormControls['q12Extra'].enable()
        } else {
          // this.personalInformationFormControls['q10'].setValue(value?.filter((each: number) => each !== 21), {emitEvent: false});
          this.personalInformationFormControls['q12Extra'].disable()
        }
        this.personalInformationFormControls['q12Extra'].setValue('')
      }
    })

    // Q13
    this.personalInformationFormControls['q13'].valueChanges.subscribe({
      next: (value: number[] | null) => {
        if (value && value.includes(99)) {
          this.personalInformationFormControls['q13Extra'].enable()
        } else {
          this.personalInformationFormControls['q13Extra'].disable()
        }
        this.personalInformationFormControls['q13Extra'].setValue('')
      }
    })

    // Q16
    this.personalInformationFormControls['q16'].valueChanges.subscribe({
      next: (value) => {
        if (value && value.includes(6)) {
          this.personalInformationFormControls['q16Extra'].enable()
        } else {
          this.personalInformationFormControls['q16Extra'].disable()
        }
        this.personalInformationFormControls['q16Extra'].setValue('')
      }
    });

    // Q17
    this.personalInformationFormControls['q17'].valueChanges.subscribe({
      next: (value) => {
        if (value && value.includes(6)) {
          this.personalInformationFormControls['q17Extra'].enable()
        } else {
          this.personalInformationFormControls['q17Extra'].disable()
        }


        if (value && value.includes(8)) {
          this.personalInformationFormControls['q17'].setValue([8], {emitEvent: false});
        } else {
          this.personalInformationFormControls['q17'].setValue(value?.filter((each: number) => each !== 8), {emitEvent: false});
        }

        this.personalInformationFormControls['q17Extra'].setValue('')
      }
    });

    // Q17A
    this.personalInformationFormControls['q17a'].valueChanges.subscribe({
      next: (value) => {
        if (value && value.includes(7)) {
          this.personalInformationFormControls['q17aExtra'].enable()
        } else {
          this.personalInformationFormControls['q17aExtra'].disable()
        }
        this.personalInformationFormControls['q17aExtra'].setValue('')

        // Make 3rd exclusive
        if (value && value.includes(3)) {
          this.personalInformationFormControls['q17a'].setValue([3], {emitEvent: false});
        } else {
          this.personalInformationFormControls['q17a'].setValue(value?.filter((each: number) => each !== 3), {emitEvent: false});
        }
      }
    });

    // Q19
    this.personalInformationFormControls['q19'].valueChanges.subscribe({
      next: (value: number[] | null) => {
        if (value && value.includes(12)) {
          this.personalInformationFormControls['q19Extra'].enable()
        } else {
          this.personalInformationFormControls['q19Extra'].disable()
        }
        this.personalInformationFormControls['q19Extra'].setValue('')
      }
    });
  }

  async closeSurveyEndModal() {
    await this.goToStep1()
  }

  openSurveyEndModal() {
    this.modal.info({
      nzTitle: 'Thank you for taking part in this survey!',
      nzOkText: 'Close',
      nzOkType: 'primary',
      nzOnOk: () => this.closeSurveyEndModal(),
      nzClosable: false,
    });
  }

  async submitSurveyForm() {
    const formData = this.surveyForm.getRawValue()

    const q8Index = `${formData.q7b}-${formData.q7a}`
    const q8 = this.q8Map[q8Index]
    const i = this.q8.indexOf(q8)

    const requestBody: any = {
      ...formData, q8: i === -1 ? 8 : i + 1,
    }

    // Recordings
    const setOfRecordings = new Set(RECORDINGS)
    const unique = [...setOfRecordings]

    for (const each of unique) {
      const id = `recording${each}`
      requestBody[id] = await this.submissionService.convertBlobToBase64(formData[id]?.audioBlob!)
    }


    navigator.geolocation.getCurrentPosition((position) => {
      requestBody.latitude = position.coords.latitude
      requestBody.longitude = position.coords.longitude
      this.apiCall(requestBody)
    }, err => {
      requestBody.latitude = 0
      requestBody.longitude = 0
      this.apiCall(requestBody)
    })
  }

  apiCall(requestBody: any) {
    this.surveySubmitStarted = true;
    console.log(requestBody)

    this.submissionService.submitForm(requestBody).subscribe({
      next: async () => {
        this.surveySubmitStarted = false;
        this.surveyEndedMessage();
        // this.toastService.success('Survey Submitted Successfully!!')
      }, error: (err) => {
        this.surveySubmitStarted = false;
        this.toastService.error(err);
      }
    })
  }

  /**
   * Survey ended successfylly message
   */
  surveyEndedMessage() {
    this.modal.success({
      nzTitle: 'Survey Submitted Successfully!!',
      nzOkText: 'Close',
      nzOkType: 'primary',
      nzOnOk: async () => await this.closeSurveyEndModal(),
      nzClosable: false,
    });
  }

  clearControl() {
    const currentStep = this.step
    if (this.stepMap[currentStep]) {
      this.stepMap[currentStep].controls.forEach((eachControl: string) => {
        this.surveyForm.get(eachControl)?.reset()
      })
    }
  }

  get currentUserInfo() {
    return this.auth.currentUser.getValue()
  }

  returnAsFormControl(control: AbstractControl) {
    return control as FormControl
  }

  switchLanguage() {
    this.language = this.language === 'english' ? 'hindi' : 'english'
  }

  async recordAudio() {
    return new Promise(resolve => {
      navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
          const mediaRecorder = new MediaRecorder(stream);
          const audioChunks: any[] = [];

          mediaRecorder.addEventListener("dataavailable", event => {
            audioChunks.push(event.data);
          });

          const start = () => {
            mediaRecorder.start();
          };

          const stop = () => {
            return new Promise(resolve => {
              mediaRecorder.addEventListener("stop", () => {
                const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
                const audioUrl = URL.createObjectURL(audioBlob);
                const audio = new Audio(audioUrl);
                const play = () => {
                  audio.play();
                };

                resolve({ audioBlob, audioUrl, play });
              });
              if(mediaRecorder.state === 'recording') {
                mediaRecorder.stop()
              } else {
                resolve(null)
              }

            });
          };

          resolve({mediaRecorder, start, stop });
        });
    });
  };

}
