export const environment = {
  production: true,
  backendUrl: 'https://btl-backend.onrender.com'
};
