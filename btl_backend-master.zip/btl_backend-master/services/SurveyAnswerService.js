module.exports = {

    questions: [
        {
            question: 'ID',
            key: 'index'
        },
        {
            question: 'Name',
            key: "name"
        },
        {
            question: 'Contact Number',
            key: "contactNumber"
        },
        {
            question: "Q1 Can you kindly tell us which city you are currently residing in?",
            key: "q1"
        },
        {
            question: "City",
            key: "q1Option"
        },
        {
            question: "Q1a.Can you kindly tell us which city you are currently residing in?", key: "q1a"
        },

        {
            question: "Q2. Have you attended or participated in any market research activity in the last 6 months?",
            key: "q2"
        },

        {
            question: "Q2a. Now kindly tell us do you work in any of these organisations?", key: "q2a"

        },

        {
            question: "Q2a. Others Specify?", key: "q2aExtra"

        },

        {
            question: "Q3. Please mention your age", key: "q3"

        },

        {
            question: "Q3a. Please tell me your age",

            key: "q3a"
        },

        {
            question: "Q4. Please select the gender", key: "q4"

        },
        {
            question: "Gender",
            key: "q4Option"
        },

        {
            question: "Q5. Are you the decision maker/s with regards to purchase of financial products for yourself or for other family members? By this, I mean, that you are either a joint or sole decision maker whenever buying financial products like Insurance, Mutual funds, Fixed Deposits, Home Loan, Credit Cards & Banking products etc.",
            key: "q5"

        },

        {
            question: "Q6a. Please tell me your Current Occupation.", key: "q6a"

        },
        {
            question: "Occupation",
            key: "q6aOption"
        },

        {
            question: "Q6d. Please tell us what your monthly salary is?", key: "q6d"

        },

        {
            question: "Q6e. Please tell us what is the monthly turnover of your business/proprietorship?", key: "q6e"

        },

        {
            question: "Q7a. Please tell me what is your current education level?", key: "q7a"

        },

        {
            question: "Q7b. Please tell me what is your current occupation? Please think about only your primary job or occupation while answering this question?",
            key: "q7b"

        },

        {
            question: "Q7b. Others Specify", key: "q7bExtra"

        },

        {
            question: "Q8 OLD SEC",

            key: "q8"   // Hidden Question//

        },
        {
            question: "Q8 OLD SEC",
            key: "q8Option"
        },

        {
            question: "Q9a. Do you currently have any ongoing loans which you have not yet fully repaid?", key: "q9a"

        },

        {
            question: "Q9b. Do you intend to take a loan in the next 6 months?",

            key: "q9b"
        },

        {
            question: "Q10. In which all below mentioned financial products have you currently invested?", key: "q10"

        },

        {
            question: "Q11. When you think about Finance Companies providing Loans, which is the first company that comes to your mind?",
            key: "q11"

        },

        {
            question: "Q11. Others Specify", key: "q11Extra"

        },

        {
            question: "Q12. And which other companies that provide Loans are you aware of ?",

            key: "q12"
        },
        {
            question: "Q12. Others Specify", key: "q12Extra"

        },

        {
            question: "Q12a. TOTAL SPONT AWARENES",

            key: "q12a"  //Hidden Question//
        },


        {
            question: "Q13. Which of these Loan giving companies are you aware of?", key: "q13"
        },

        {
            question: "Q13. Others Specify", key: "q13Extra"

        },

        // {
        //     question: "Q13a. TOTAL AWARENESS",
        //
        //     key: "q13a"  //Hidden Question//
        // },

        {
            question: "Q14. Have you seen this billboard anywhere in your city?",

            key: "q14"
        },

        {
            question: "Q15. Could you tell us which brand this Billboard is for?", key: "q15"

        },

        {
            question: "Q16. You said you have seen the Billboard put out by Piramal, could you tell us what you remember from the BillBoard?",

            key: "q16"
        },

        {
            question: "Q16. Others Specify",

            key: "q16Extra"
        },

        {
            question: "Q17. You said you have seen the Billboard put out by Piramal, could you tell us what action did you perform after seeing the BillBoard?",

            key: "q17"
        },

        {
            question: "Q17. Others Specify",

            key: "q17Extra"
        },

        {
            question: "Q17a. You said you visited the Piramal branch. Could you tell us what did you do after visiting the branch?",
            key: "q17a"
        },

        {
            question: "Q17a. Others Specify", key: "q17aExtra"
        },

        {
            question: "Q18. Have you seen this billboard anywhere in your city?",

            key: "q18"
        },

        {
            question: "Q19. What did you think of this Billboard?",

            key: "q19"

        },

        {
            question: "Q19. Others Specify",

            key: "q19Extra"

        },
        {
            question: "Q20. If you were to take a loan in the next 3 months and saw this Billboard, how likely are you to apply with the company which has put up this Billboard?",

            key: "q20"
        },
        {
            question: "Center Email",

            key: "interviewer"
        },
        {
            question: "Interview Start",
            key: "interviewDateStart"
        },
        {
            question: "Interview Date",

            key: "interviewDate"
        },
        {
            question: "Interviewer Name",

            key: "surveyorName"
        },
        {
            question: "Interview ID",

            key: "surveyorId"
        },
        {
            question: "Question 3 Audio",

            key: "recording5"
        },
        {
            question: "Question 5 Audio",

            key: "recording7"
        },
        {
            question: "Question 6 Audio",

            key: "recording9"
        },
        {
            question: "Question 9a Audio",

            key: "recording12"
        },
        {
            question: "Question 9b Audio",

            key: "recording13"
        },
        {
            question: "Question 11 Audio",

            key: "recording15"
        },
        {
            question: "Question 12 Audio",

            key: "recording16"
        },
        {
            question: "Question 15 Audio",

            key: "recording19"
        },
        {
            question: "Latitude",

            key: "latitude"
        },
        {
            question: "Longitude",

            key: "longitude"
        },


    ],


    q1English: ["Panipat", "Rohtak", "Ambala", "Karnal", "Indore", "Gwalior", "Ludhiana", "Jalandhar", "Amritsar", "Mohali", "Chandigarh", "Jodhpur", "Bhilwara", "Udaipur", "Others"],
    q4English: ['Male', 'Female',],
    q6aEnglish: ["Salaried", "Businessman/Industrialist with No employees", "Businessman/Industrialist with 1-9 employees", "Businessman/Industrialist with 10+ employees", "Self-employed (Doctor, lawyer, CA etc.)", "Not working/Student", "Retired"],
    q8: ["A1", "A2", "B1", "B2", "C", "D", "E1", "E2"],

}
