const _ = require("lodash")
const fs = require("fs");

/**
 *
 * @param base64String {string}
 * @param outputPath
 * @return {Promise<unknown>}
 */
function base64ToFile2(base64String, outputPath) {

    const s = base64String.replace('data:audio/wav;base64,', '')
    const binaryString = Buffer.from(s, 'base64').toString('binary');

    return new Promise(resolve => {
        fs.writeFile(outputPath, binaryString, 'binary', (err) => {
            if (err) {
                resolve('')
            } else {
                resolve(outputPath)
            }
        });
    })
}

function deleteFile(filePath) {
    return new Promise(resolve => {
        fs.unlink(filePath, (err) => {
            if (err) {
                console.error('Error deleting file:', err);
            } else {
                // console.log('File deleted successfully:', filePath);
                resolve({})
            }
        });
    })
}


module.exports = {
    base64ToFile2,
    generateRandomFileName: (name) => {
        const timestamp = new Date().getTime();
        const randomString = Math.random().toString(36).substring(2, 8); // Adjust the length of the random string as needed
        const randomFileName = `${name}_${timestamp}_${randomString}`;
        return randomFileName;
    },
    deleteFile,

    option8Value: (request) => {
        const q8Map = {
            "1-1": "E2",
            "2-1": "E2",
            "3-1": "E2",
            "4-1": "D",
            "5-1": "D",
            "6-1": "C",
            "7-1": "B1",
            "8-1": "D",
            "9-1": "D",
            "10-1": "D",
            "11-1": "C",
            "12-1": "B1",


            "1-2": "E2",
            "2-2": "E1",
            "3-2": "D",
            "4-2": "D",
            "5-2": "C",
            "6-2": "B2",
            "7-2": "B1",
            "8-2": "D",
            "9-2": "D",
            "10-2": "D",
            "11-2": "C",
            "12-2": "B1",


            "1-3": "E1",
            "2-3": "D",
            "3-3": "D",
            "4-3": "C",
            "5-3": "B2",
            "6-3": "B2",
            "7-3": "A2",
            "8-3": "D",
            "9-3": "D",
            "10-3": "C",
            "11-3": "C",
            "12-3": "B1",

            "1-4": "D",
            "2-4": "C",
            "3-4": "C",
            "4-4": "B2",
            "5-4": "B1",
            "6-4": "B1",
            "7-4": "A2",
            "8-4": "B2",
            "9-4": "C",
            "10-4": "C",
            "11-4": "B2",
            "12-4": "B1",


            "1-5": "D",
            "2-5": "C",
            "3-5": "C",
            "4-5": "B1",
            "5-5": "A2",
            "6-5": "A2",
            "7-5": "A1",
            "8-5": "B1",
            "9-5": "B2",
            "10-5": "B2",
            "11-5": "B1",
            "12-5": "A2",


            "1-6": "D",
            "2-6": "B2",
            "3-6": "B1",
            "4-6": "A2",
            "5-6": "A2",
            "6-6": "A1",
            "7-6": "A1",
            "8-6": "A2",
            "9-6": "B1",
            "10-6": "B1",
            "11-6": "A2",
            "12-6": "A1",


            "1-7": "D",
            "2-7": "B2",
            "3-7": "B1",
            "4-7": "A2",
            "5-7": "A2",
            "6-7": "A1",
            "7-7": "A1",
            "8-7": "A2",
            "9-7": "B1",
            "10-7": "B1",
            "11-7": "A2",
            "12-7": "A1",


            "1-8": "D",
            "2-8": "B2",
            "3-8": "B2",
            "4-8": "A2",
            "5-8": "A1",
            "6-8": "A1",
            "7-8": "A1",
            "8-8": "A1",
            "9-8": "B1",
            "10-8": "A2",
            "11-8": "A2",
            "12-8": "A1",


            "1-9": "D",
            "2-9": "B2",
            "3-9": "B2",
            "4-9": "A2",
            "5-9": "A1",
            "6-9": "A1",
            "7-9": "A1",
            "8-9": "A1",
            "9-9": "B1",
            "10-9": "A2",
            "11-9": "A2",
            "12-9": "A1",
        }
        const q8Arr = ["A1", "A2", "B1", "B2", "C", "D", "E1", "E2"]
        const q8Index = `${request.q7b}-${request.q7a}`
        const q8Mapped = q8Map[q8Index]
        const indexOfQ8 = q8Arr.indexOf(q8Mapped)
        return indexOfQ8 === -1 ? 0 : indexOfQ8 + 1
    },
    option12aValue: (request) => {
        const setOfValues = new Set([request.q11, ...request.q12])
        return [...setOfValues]
    }

}
