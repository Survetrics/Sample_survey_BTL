const {Storage} = require("@google-cloud/storage");

// Replace with your GCP project details
const projectId = 'festive-magpie-416205';
const keyFilename = 'path/to/your/keyfile.json';

// Replace with your GCS bucket name
const bucketName = 'festive-magpie-416205.appspot.com';

const storage = new Storage({keyFilename: "Gkey.json"});

module.exports = {

    /**
     * Upload file from path to gcp
     * @param bufferData
     * @return {Promise<unknown>}
     */
    uploadFileFromPath: async (bufferData) => {
        try {
            const result = await storage.bucket(bucketName).upload(bufferData, {
                metadata: {cacheControl: 'public'}
            });

            return result[1].mediaLink

        } catch (exception) {
            return '';
        }
    }
}
