const mongoose = require('mongoose');
const Schema = mongoose.Schema

const surveySchema = new mongoose.Schema({
    name: { type: Schema.Types.Mixed, default: '', required: false },
    contactNumber: { type: Schema.Types.Mixed, default: '', required: false },
    address: { type: Schema.Types.Mixed, default: '', required: false },

    q1: { type: Schema.Types.Mixed, default: null, required: false },
    q1a: { type: Schema.Types.Mixed, required: false },

    q2: { type: Schema.Types.Mixed, required: false },
    q2a: { type: Schema.Types.Mixed, required: false },
    q2aExtra: { type: String, default: '', required: false },

    q3: { type: Schema.Types.Mixed, required: false },
    q3a: { type: Schema.Types.Mixed, required: false },

    q4: { type: Schema.Types.Mixed, required: false },

    q5: { type: Schema.Types.Mixed, required: false },

    q6a: { type: Schema.Types.Mixed, required: false },
    q6d: { type: Schema.Types.Mixed, required: false },
    q6e: { type: Schema.Types.Mixed, required: false },

    q7a: { type: Schema.Types.Mixed, required: false },
    q7b: { type: Schema.Types.Mixed, required: false },
    q7bExtra: { type: String, required: false },
    q8: { type: Schema.Types.Mixed, required: false, default: 0 },

    q9a: { type: Schema.Types.Mixed, required: false },
    q9b: { type: Schema.Types.Mixed, required: false },

    q10: { type: Schema.Types.Mixed, required: false },

    q11: { type: Schema.Types.Mixed, required: false },
    q11Extra: { type: String, default: null, required: false },

    q12: { type: Schema.Types.Mixed, required: false },
    q12Extra: { type: Schema.Types.Mixed, required: false },

    q12a: { type: Schema.Types.Mixed, required: false },

    q13: { type: Schema.Types.Mixed, required: false },
    q13Extra: { type: Schema.Types.Mixed, required: false },

    q14: { type: Schema.Types.Mixed, required: false },

    q15: { type: Schema.Types.Mixed, required: false },

    q16: { type: Schema.Types.Mixed, required: false },
    q16Extra: { type: String, required: false },

    q17: { type: Schema.Types.Mixed, required: false },
    q17Extra: { type: String, required: false },

    q17a: { type: Schema.Types.Mixed, required: false },
    q17aExtra: { type: String, required: false },

    q18: { type: Schema.Types.Mixed, required: false },

    q19: { type: Schema.Types.Mixed, required: false },
    q19Extra: { type: String, required: false },

    q20: { type: Schema.Types.Mixed, required: false },

    latitude: { type: Schema.Types.Mixed, default: 0, required: false },
    longitude: { type: Schema.Types.Mixed, default: 0, required: false },

    interviewer: { type: String, required: false, default: '' },
    interviewDate: { type: Schema.Types.Mixed, required: false, default: '' },
    surveyorName: { type: Schema.Types.Mixed, required: false, default: '' },
    surveyorId: { type: Schema.Types.Mixed, required: false, default: '' },

    recording5: { type: Schema.Types.Mixed, required: false, default: '' },
    recording7: { type: Schema.Types.Mixed, required: false, default: '' },
    recording9: { type: Schema.Types.Mixed, required: false, default: '' },
    recording12: { type: Schema.Types.Mixed, required: false, default: '' },
    recording13: { type: Schema.Types.Mixed, required: false, default: '' },
    recording15: { type: Schema.Types.Mixed, required: false, default: '' },
    recording16: { type: Schema.Types.Mixed, required: false, default: '' },
    recording19: { type: Schema.Types.Mixed, required: false, default: '' },
    interviewDateStart: { type: Schema.Types.Mixed, required: false, default: '' },

})

module.exports = mongoose.model('Survey', surveySchema, "BTL_Survey")
